import java.awt.*;
import java.awt.event.*;
import java.util.Random;
import javax.swing.*;

 // The main class for the "Pick Your Path" game.
  public class PickYourPath{
 // Game board dimensions.
      int boardWidth = 600;
      int boardHeight = 650;

      JFrame frame = new JFrame("Mario:Pick Your Path");
      JLabel textLabel = new JLabel();
      JPanel textPanel = new JPanel();
      JPanel boardPanel = new JPanel();

      JButton[] board = new JButton[9];
      ImageIcon moleIcon;
      ImageIcon plantIcon;

      JButton currMoleTile;
      JButton currPlantTile;
 // Random number generator.
      Random random =new Random();
      Timer setMoleTimer;
      Timer setPlantTimer;
      int score = 0;
         
 
 // Constructor for the PickYourPath class.
      PickYourPath(){
 

      //frame.setVisible(true);
      frame.setSize(boardWidth, boardHeight);
      frame.setLocationRelativeTo(null);
      frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
      frame.setResizable(false);
      frame.setLayout(new BorderLayout());

      textLabel.setFont(new Font("Arial", Font.PLAIN, 50));
      textLabel.setHorizontalAlignment(JLabel.CENTER);
      textLabel.setText("Score:0");
      textLabel.setOpaque(true);

      textPanel.setLayout(new BorderLayout());
      textPanel.add(textLabel);
      frame.add(textPanel, BorderLayout.NORTH);

      boardPanel.setLayout(new GridLayout(3, 3));
      frame.add(boardPanel);

    // Load the plant image.
      Image plantImg = new ImageIcon(getClass().getResource("./Wrong.jpg")).getImage();
      plantIcon = new ImageIcon(plantImg.getScaledInstance(150, 150, java.awt.Image.SCALE_SMOOTH));

    // Load the mole image.
      Image moleImg = new ImageIcon(getClass().getResource("./Right.jpg")).getImage();
      moleIcon = new ImageIcon(moleImg.getScaledInstance(150, 150, java.awt.Image.SCALE_SMOOTH));
      score = 0;

    // Create and set up the 9 buttons on the board.
      for(int i = 0; i<9; i++){
        JButton tile = new JButton();
        board[i] = tile;
        boardPanel.add(tile);
        tile.setFocusable(false);
    //tile.setIcon(moleIcon);
        tile.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent e){
            JButton tile = (JButton) e.getSource();
   // Check if the clicked tile is the mole tile.
            if(tile == currMoleTile){
              score += 10;
              textLabel.setText("Score:" + Integer.toString(score));
            }
  // Check if the clicked tile is the plant tile.
            else if (tile == currPlantTile) {
              textLabel.setText("Game Over:" + Integer.toString(score));
              setMoleTimer.stop();
              setPlantTimer.stop();
  // Disable all buttons if game over
              for(int i = 0; i<9; i++){
                board[i].setEnabled(false);
              }
            }
          }
        });
      }
 // Timer to handle the mole appearance.
      setMoleTimer = new Timer(1000, new ActionListener() {
        public void actionPerformed(ActionEvent e){
          if(currMoleTile != null){
            currMoleTile.setIcon(null);
            currMoleTile = null;
          }
           
          int num = random.nextInt(9);
          JButton tile = board[num];

          if(currPlantTile == tile) return;

          currMoleTile = tile;
          currMoleTile.setIcon(moleIcon);
        }
      });
// Timer to handle the plant appearance.
      setPlantTimer = new Timer(1500, new ActionListener() {
        public void actionPerformed(ActionEvent e){
          if(currPlantTile != null){
            currPlantTile.setIcon(null);
            currPlantTile = null;
          }
           
          int num = random.nextInt(9);
          JButton tile = board[num];

          if(currMoleTile == tile) return;

          currPlantTile = tile;
          currPlantTile.setIcon(plantIcon);
        }
      });
  // Start the timers for plant and mole movement.
      setPlantTimer.start();
      setMoleTimer.start();
      frame.setVisible(true);
  }
// Main method to run the game
  public static void main(String[] args) {
    SwingUtilities.invokeLater(() -> {
       new PickYourPath();
     });
}
}